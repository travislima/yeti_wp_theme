<?php get_header() ?>

<h1> THIS IS MY FIRST EVER THEME</h1>

<?php get_footer() ?>